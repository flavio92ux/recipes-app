export default function Head() {
  return (
    <>
      <link rel="image_src" href="http://localhost:3000/og-image.png" />
    </>
  );
}
